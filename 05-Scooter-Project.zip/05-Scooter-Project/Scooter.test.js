const Scooter = require('./Scooter',)

test('Customer Information', () => {
    expect(Customer("name", "email", "phoneNumber", "age", "bankNumber")).toEqual("","","","","")
});




