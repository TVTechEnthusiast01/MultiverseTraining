class Customer{
    constructor(name, email, phoneNumber, age, bankNumber){
    this.name = name;
    this.email = email;
    this.phoneNumber= phoneNumber;
    this.age = age;
    this.bankNumber = bankNumber
    
    this.ScooterID = [];
    };
    addScooter (ScooterID){
        this.ScooterID.push(ScooterID)
    }
 }

class DockingScooter { 
    constructor (scooter){ 
        this.scooter=scooter;
        this.scooterID=[];
    };
    addScooter (Customer) {
        this.ScooterID.push(ScooterID)
        
    }
}

const Saied = new Customer ( "Saied", "Saied123@gmail.com", "08939144040", "20", "23928893289")
Saied.addScooter("Saied is using Scooter ID 90328")
console.log(Saied)

const readline = require("readline");

const q1 = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

q1.question("Would you like to report the Scooter as broken? Yes/No", (answer) => {
    if (answer === "Yes" || "yes") {
        console.log("Maintenance has been dispatched to fix it, please choose another scooter");
    }
    
    else if (answer === "No" || "no"){
        console.log("Thanks for using our scooter");
    };
    
    console.log("Have a nice day");

      q1.close();
  });






























